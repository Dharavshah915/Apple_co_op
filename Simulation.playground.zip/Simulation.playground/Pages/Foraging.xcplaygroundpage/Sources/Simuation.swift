import Foundation

public func startSimulation() {
    startSimulation(withFoodPiles: 5)    
}
