import Foundation

public func startSimulation() {
    homePheromoneDepositRate = 0
    startSimulation(withFoodPiles: 0)
}
