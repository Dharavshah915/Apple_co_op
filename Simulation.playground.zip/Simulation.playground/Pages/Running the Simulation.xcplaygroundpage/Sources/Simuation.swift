import Foundation

public func startSimulation() {
//    homePheromoneDecayRate = 50
//    homePheromoneDepositRate = 800
//    homePheromoneDepositFalloffRate = 0
//    foodPheromoneDecayRate =

    startSimulation(withFoodPiles: 5)
}
