//: ## Game 1
let adjective1 = "fluffy"
let noun = "rabbit"
let number = "9"
let adjective2 = "strong"
let plural_noun = "carrots"

let story = "Once apon a time a \(adjective1)\(noun) ate \(number) of the best \(adjective2)\(plural_noun) in the world"
print(story)
//: [Previous](@previous)  |  page 3 of 7  |  [Next: Game 2](@next)
